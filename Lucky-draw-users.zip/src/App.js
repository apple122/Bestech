import logo from './logo.svg';
import './App.css';
import './assets/CSS/style.css'
import './assets/CSS/DarkMode.css'
import Header from './Component/Header-Footer';
import Routers from './Routers/Routers';

function App() {
  return (
    <>
      <Header />
    </>
  );
}

export default App;
