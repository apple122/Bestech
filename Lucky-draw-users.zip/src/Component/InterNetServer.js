import React from 'react'

export default function InterNetServer() {
  return (
    <>
        <div className="INterNetERROR user-select-none">
          <div className="text-white text-center">
            <div class="spinner-border p-5" role="status">
              <span class="sr-only">Loading...</span>
            </div>
            <p className="Nato_sanlaos">ສະລຸນາລໍຖ້າ...</p>
          </div>
        </div>
    </>
  )
}
