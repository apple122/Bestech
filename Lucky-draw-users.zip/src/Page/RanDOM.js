import React from 'react'
import { Link } from 'react-router-dom'
import LuckyDraw from './luckydraw/LuckyDraw'

export default function RanDOM() {
  return (
    <>
      <LuckyDraw/>
    </>
  )
}
